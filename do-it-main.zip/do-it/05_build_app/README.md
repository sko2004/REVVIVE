# Step 5 — Build App & Docker Image

**Do-It** › **Vayu Container Registry & Realtime Inference** · `05_build_app/`

| | |
|---|---|
| **Previous** | [Step 4 — Agent starter kit](../04_starter_kit/) |
| **Next** | [Step 6 — Deploy ML Service →](../06_deploy/) |

Build the **Do-It** Streamlit agent app and Docker image locally, then continue to [Step 6 — Deploy](../06_deploy/) for the hosted **Vayu ML Service** endpoint.

---

## Pipeline flow

```text
User request (app.py)
        │
        ▼
Planner loop (llm_agent.py → Vayu Model as a Service + tools)
        │
        ├── Task CRUD / search (Vayu Vector DB)
        ├── Trace logging (Vayu Managed PostgreSQL)
        └── HITL approvals (pending_actions → Approvals tab)
        │
        ▼
Streamlit UI (port 8501)
```

---

## What's In This Step?

| File | Description |
|------|-------------|
| `app.py` | Streamlit interface (Tasks, Agent, Approvals) |
| `Dockerfile` | Production-ready image for **Vayu Hackathon Container Registry** |
| `.dockerignore` | Prevents non-essential files from being copied into the container |

All agent logic lives in `04_starter_kit/` and is copied into the image at build time.

---

## Prerequisites

- [Step 4 — Agent starter kit](../04_starter_kit/) completed — agent modules tested locally
- Env vars from [Step 1 — Vayu Vector DB](../01_vayu_vector_databases/), [Step 2 — Vayu Managed PostgreSQL](../02_vayu_postgres/), and [Step 3 — Vayu Model as a Service](../03_vayu_model_as_a_service/)

---

## Run Locally (Dev Mode)

```bash
cd do-it
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

cp .env.example .env
# Edit .env with your Vayu Vector DB, Postgres, and Model as a Service credentials

streamlit run 05_build_app/app.py
```

- Open your browser at **http://localhost:8501**
- When running inside a **Vayu AI Studio workspace**, use the workspace proxy URL instead (e.g. `https://<your-workspace-host>/proxy/8501`)
- Use **Tasks** to add items, **Agent** to run the planner, and **Approvals** for HITL deletes

---

## Build and push Docker image

The `Dockerfile` lives in this folder, but the **build context** must be the parent **`do-it/`** directory (one level up), because the image copies `requirements.txt` and `04_starter_kit/` from there.

| | Path |
|---|------|
| **Build from** | `do-it/` |
| **Dockerfile** | `do-it/05_build_app/Dockerfile` |
| **Do not build from** | `05_build_app/` (will fail on `COPY`) |

1. Log in to your hackathon / Vayu container registry:

   ```bash
   docker login <YOUR_CONTAINER_REGISTRY_HOST>
   ```

2. Build and push from the `do-it/` root:

   ```bash
   cd do-it

   docker build -f 05_build_app/Dockerfile -t <YOUR_CONTAINER_REGISTRY_HOST>/do-it-agent:latest . --push
   ```

3. Note the full image reference (e.g. `<YOUR_CONTAINER_REGISTRY_HOST>/do-it-agent:latest`) — you will enter it in the ML Service wizard in [Step 6](../06_deploy/).

| Check | |
|-------|---|
| Port in image | **8501** (Streamlit; see `EXPOSE` in Dockerfile) |
| Secrets | **Not** baked into the image — only at runtime |

---

## Environment variables

| Variable | Required | Used by | Purpose |
|----------|----------|---------|---------|
| `DATABASE_URL` | Yes | `postgres_db.py` | **Vayu Managed PostgreSQL** connection |
| `QDRANT_URL` | Yes | `qdrant_tasks.py` | Vayu Vector DB endpoint |
| `QDRANT_API_KEY` | Yes | `qdrant_tasks.py` | Vector DB auth |
| `OPENAI_API_KEY` | Yes | `llm_agent.py` | MaaS chat API key |
| `OPENAI_BASE_URL` | Yes | `llm_agent.py` | MaaS base URL |
| `CHAT_MODEL` | Yes | `llm_agent.py` | Chat model ID |
| `COLLECTION_NAME` | No | `qdrant_tasks.py` | Task collection name |

---

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| Agent fails to connect to Postgres | Check `DATABASE_URL`; use external hostname (not `localhost`) in Docker |
| Agent can't see tasks | Verify `QDRANT_URL` / `COLLECTION_NAME` |
| Model errors | Confirm `CHAT_MODEL` / `OPENAI_BASE_URL`; check API key and credits |
| Page won't load in workspace | Use the proxy URL (`/proxy/8501`) instead of `localhost` |
| Docker build fails on `COPY` | Build from `do-it/` root, not `05_build_app/` |

---

## Next: deploy to Vayu ML Service

After the image is pushed to your registry, follow **[Step 6 — Deploy](../06_deploy/README.md)** for the ML Service wizard (port **8501**, environment variables, public URL, and demo checklist).

---

## Navigation

| | |
|---|---|
| **Previous** | [Step 4 — Agent starter kit](../04_starter_kit/) |
| **Next** | [Step 6 — Deploy ML Service →](../06_deploy/) |
| **🏠 Overview** | [Do-It overview](../README.md) |
