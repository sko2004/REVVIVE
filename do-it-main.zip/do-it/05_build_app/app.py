"""
Do-It — Streamlit UI: Qdrant tasks + Postgres-backed agent trace + HITL.

Run: streamlit run app.py
"""

from __future__ import annotations

from pathlib import Path

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent.parent / ".env")

import os
from uuid import UUID

import streamlit as st

import llm_agent
import postgres_db as db
from qdrant_tasks import (
    add_task,
    collection_name,
    delete_task,
    ensure_collection,
    list_tasks,
    search_tasks,
    set_done,
)


def _db_connect_help(exc: Exception) -> None:
    msg = str(exc).lower()
    if any(
        x in msg
        for x in (
            "name or service not known",
            "resolve host",
            "could not translate host",
            "nodename nor servname",
            "temporary failure in name resolution",
        )
    ):
        st.warning(
            "**Hostname in `DATABASE_URL` is wrong or unreachable.** "
            "Use the exact host and port from your hosted Postgres provider. "
            "Inside Docker, `localhost` refers to the container — use the URL your provider gives for external access."
        )
    elif "password authentication failed" in msg or "authentication failed" in msg:
        st.warning("Check **username** and **password** in `DATABASE_URL` (URL-encode special characters).")
    elif "ssl" in msg or "tls" in msg or "certificate" in msg:
        st.warning("Try appending **`?sslmode=require`** to `DATABASE_URL` if your provider requires TLS.")
    elif "call postgres_db.ensure_tables" in msg or "postgresql is not ready" in msg:
        st.warning("Database layer was used before startup completed; use **Reload Postgres cache** or restart the app.")
    st.markdown(
        "Tables are created by ``postgres_db.ensure_tables()`` on first load. "
        "Optional manual DDL: ``psql \"$DATABASE_URL\" -f db/schema.sql``."
    )


@st.cache_resource
def get_qdrant_client():
    return ensure_collection()


@st.cache_resource
def bootstrap_postgres() -> bool:
    db.ensure_tables()
    return True


def render_tasks_tab(client) -> None:
    st.subheader("Add a task")
    title = st.text_input("Title", placeholder="Buy milk", key="t_title")
    description = st.text_area("Description (optional)", height=68, placeholder="2% organic…", key="t_desc")
    if st.button("Add task", type="primary", key="t_add"):
        try:
            add_task(client, title, description)
            st.success("Task added.")
            st.rerun()
        except ValueError as err:
            st.warning(str(err))

    st.divider()
    st.subheader("Search")
    query = st.text_input("Keyword", placeholder="Leave empty to show all", key="t_q")

    tasks = search_tasks(client, query) if query.strip() else list_tasks(client)

    if not tasks:
        st.info("No tasks yet. Add one above, or ask the Agent tab.")
        return

    st.write(f"**{len(tasks)}** task(s)")
    for t in tasks:
        with st.container(border=True):
            status = "✅ Done" if t["done"] else "⏳ Open"
            st.markdown(f"{status} · **{t['title']}**")
            if t.get("description"):
                st.caption(t["description"])
            st.caption(f"`{t['id'][:8]}…` · {t.get('created', '')[:19]}")

            b1, b2 = st.columns(2)
            with b1:
                if t["done"]:
                    if st.button("Reopen", key=f"reopen_{t['id']}"):
                        set_done(client, t["id"], False)
                        st.rerun()
                else:
                    if st.button("Complete", key=f"done_{t['id']}"):
                        set_done(client, t["id"], True)
                        st.rerun()
            with b2:
                if st.button("Delete now", key=f"del_{t['id']}", help="Manual delete — no HITL"):
                    delete_task(client, t["id"])
                    st.rerun()


def render_agent_tab(client) -> None:
    st.subheader("Agent chat")
    st.caption(
        "OpenAI-compatible **tools** + **PostgreSQL** trace. Agent deletes require **Approvals**."
    )

    try:
        bootstrap_postgres()
    except Exception as e:
        st.error(f"PostgreSQL: {e}")
        _db_connect_help(e)
        return

    if not os.environ.get("OPENAI_API_KEY", "").strip():
        st.warning("Set **OPENAI_API_KEY** in `do-it/.env` (and **OPENAI_BASE_URL**, **CHAT_MODEL**).")

    user_msg = st.text_area("Your message", height=100, key="agent_msg", placeholder="List my open tasks")
    if st.button("Run agent", type="primary", key="agent_go"):
        if not os.environ.get("OPENAI_API_KEY", "").strip():
            st.error("OPENAI_API_KEY is required.")
            return
        with st.spinner("Planning and calling tools…"):
            result = llm_agent.run_agent(client, user_msg.strip())
        st.session_state["last_agent_result"] = result
        st.rerun()

    res = st.session_state.get("last_agent_result")
    if res:
        if res.get("ok"):
            st.success("Run completed.")
            st.markdown(res.get("answer") or "_No text reply._")
        else:
            st.error(res.get("error", "Unknown error"))
        st.caption(f"Run id: `{res.get('run_id')}`")
        with st.expander("Trace (`agent_steps`)", expanded=False):
            for row in res.get("trace") or []:
                st.json(
                    {
                        "step": row.get("step_no"),
                        "kind": row.get("kind"),
                        "tool": row.get("tool_name"),
                        "payload": row.get("payload"),
                    },
                    expanded=False,
                )


def render_approvals_tab(client) -> None:
    st.subheader("Pending delete approvals (HITL)")
    st.caption("When the agent calls `queue_task_delete`, rows appear here.")

    try:
        bootstrap_postgres()
    except Exception as e:
        st.error(f"PostgreSQL: {e}")
        _db_connect_help(e)
        return

    pending = db.list_pending_actions()
    if not pending:
        st.info("No pending delete requests.")
        return

    for row in pending:
        pid = row["id"]
        st.write(f"**{row.get('task_title', '?')}** — `{row.get('task_id', '')[:12]}…`")
        c1, c2 = st.columns(2)
        with c1:
            if st.button("Approve delete", key=f"ap_{pid}"):
                out = db.resolve_pending(UUID(str(pid)), "approved", note="streamlit")
                if out:
                    delete_task(client, out["task_id"])
                    st.success("Deleted from Qdrant.")
                else:
                    st.warning("Already resolved.")
                st.rerun()
        with c2:
            if st.button("Reject", key=f"rj_{pid}"):
                db.resolve_pending(UUID(str(pid)), "rejected", note="streamlit")
                st.info("Rejected.")
                st.rerun()


def main() -> None:
    st.set_page_config(page_title="Do-It", page_icon="✅", layout="wide")
    st.title("Do-It")
    st.caption("**Vayu Vector DB** tasks + **Postgres** trace + **Vayu Model as a Service** tools.")

    try:
        client = get_qdrant_client()
    except Exception as e:
        st.error(str(e))
        st.info("Set **QDRANT_URL** + **QDRANT_API_KEY**, or **QDRANT_PATH** for local Qdrant.")
        return

    with st.sidebar:
        st.subheader("Qdrant collection")
        st.code(collection_name(), language="text")
        if st.button("Refresh Qdrant cache"):
            get_qdrant_client.clear()
            st.rerun()
        st.divider()
        st.markdown("**Postgres** — modules: `postgres_db`, `qdrant_tasks`, `llm_agent`, `agent_tools`.")
        if st.button("Reload Postgres cache"):
            db.clear_connection_string_cache()
            bootstrap_postgres.clear()
            st.rerun()

    tab_tasks, tab_agent, tab_hitl = st.tabs(["Tasks", "Agent", "Approvals"])

    with tab_tasks:
        render_tasks_tab(client)
    with tab_agent:
        render_agent_tab(client)
    with tab_hitl:
        render_approvals_tab(client)


if __name__ == "__main__":
    main()
